# دليل النشر الدائم بدون انقطاع - تصميم المعلمة زكيه الطلحي

## ⚠️ لماذا الرابط الحالي ينقطع؟

الرابط `https://5000-....e2b.app` يعمل داخل بيئة تطوير مؤقتة (E2B Sandbox) - يتوقف عند إغلاق الصفحة. هو للاختبار فقط.

## ✅ 3 حلول دائمة مجانية

### الحل 1: Render.com (أنصح به للبداية) - دائم ومجاني

1. سجلي في https://render.com (مجاني)
2. أنشئي مستودع GitHub وارفعي هذه الملفات:
   - supervisor_dashboard_app.py
   - requirements.txt
   - Procfile
   - runtime.txt
   - render.yaml
3. في Render: New → Web Service → اختاري المستودع
   - Build: `pip install -r requirements.txt`
   - Start: `gunicorn supervisor_dashboard_app:app --bind 0.0.0.0:$PORT`
4. ستحصلين على رابط دائم مثل:
   - `https://moshrefon-hots-dashboard.onrender.com/student` (للمتدربين)
   - `https://moshrefon-hots-dashboard.onrender.com/supervisor` (لك - كلمة المرور Moshrefon@2026)

**ملاحظة:** الخطة المجانية تنام بعد 15 دقيقة وتستيقظ عند أول زيارة (30 ثانية تأخير).

---

### الحل 2: PythonAnywhere - دائم 100% بدون نوم

1. سجلي في https://www.pythonanywhere.com (مجاني)
2. Files → Upload → supervisor_dashboard_app.py
3. Bash: `pip install flask flask-cors --user`
4. Web → Add new web app → Manual → Python 3.11
5. في WSGI file الصقي:
```python
import sys
path = '/home/USERNAME/mysite'
if path not in sys.path:
    sys.path.append(path)
from supervisor_dashboard_app import app as application
```
6. Reload → رابط دائم: `https://USERNAME.pythonanywhere.com/student`

---

### الحل 3: Google Sheets بدون خادم - دائم للأبد (أفضل حل) 🏆

هذا الحل **بدون خادم نهائياً** - يعمل على GitHub Pages للأبد.

#### الخطوات:

1. أنشئي Google Sheet جديد بعناوين:
   `code | pre_score | pre_percent | post_score | post_percent | improvement | pre_date | post_date | status`

2. Extensions → Apps Script → الصقي هذا الكود:

```javascript
function doPost(e) {
  try {
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
    var data = JSON.parse(e.postData.contents);
    var code = data.code;
    var rows = sheet.getDataRange().getValues();
    var foundRow = -1;
    for (var i=1; i<rows.length; i++){
      if (rows[i][0]==code){ foundRow=i+1; break; }
    }
    var rowData = [
      code,
      data.pre_score || '',
      data.pre_percent || '',
      data.post_score || '',
      data.post_percent || '',
      (data.post_percent && data.pre_percent) ? (data.post_percent - data.pre_percent) : '',
      data.pre_date || '',
      data.post_date || '',
      data.post_score ? 'مكتمل' : 'قبلي فقط'
    ];
    if (foundRow>0){
      sheet.getRange(foundRow,1,1,rowData.length).setValues([rowData]);
    } else {
      sheet.appendRow(rowData);
    }
    return ContentService.createTextOutput(JSON.stringify({status:'success'})).setMimeType(ContentService.MimeType.JSON);
  } catch(err){
    return ContentService.createTextOutput(JSON.stringify({status:'error', message: err.toString()})).setMimeType(ContentService.MimeType.JSON);
  }
}
function doGet(e){
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var rows = sheet.getDataRange().getValues();
  var headers = rows[0];
  var result = [];
  for (var i=1;i<rows.length;i++){
    var obj={};
    for (var j=0;j<headers.length;j++){ obj[headers[j]]=rows[i][j]; }
    result.push(obj);
  }
  return ContentService.createTextOutput(JSON.stringify(result)).setMimeType(ContentService.MimeType.JSON);
}
```

3. Deploy → New deployment → Web app → Anyone → Deploy → انسخي رابط /exec

4. افتحي ملف `تطبيق_سحابي_دائم_GoogleSheets_بدون_خادم.html` وابحثي عن:
   `const GOOGLE_SCRIPT_URL = ""`
   وضعي رابطك هناك.

5. ارفعي الملف على GitHub Pages أو Netlify (مجاني) → يعمل للأبد بدون خادم!

#### لوحة المشرف الدائمة:
افتحي `لوحة_المشرف_الدائمة_GoogleSheets_تقرأ_من_GoogleSheet.html` وضعي نفس الرابط → ستقرأ من Google Sheet تلقائياً.

---

## 📦 الملفات الجاهزة في الحقيبة

- supervisor_dashboard_app.py (محدث لقراءة PORT من البيئة)
- requirements.txt
- Procfile
- runtime.txt
- render.yaml
- تطبيق_سحابي_دائم_GoogleSheets_بدون_خادم.html (يعمل بدون خادم)
- لوحة_المشرف_الدائمة_GoogleSheets_تقرأ_من_GoogleSheet.html
- دليل_النشر_الدائم_بدون_انقطاع.html (دليل مرئي)

## 🌟 التوصية

- **سريع ودائم:** PythonAnywhere (10 دقائق)
- **احترافي:** Render.com
- **يدوم للأبد بدون خادم:** Google Sheets (أنصح به)
